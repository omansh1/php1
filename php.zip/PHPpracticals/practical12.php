<h1>Prime number program</h1>
<?php

if (isset($_POST['submit'])) {
	$number = $_POST['number'];
	$result = true;
	for ($i=2; $i <$number ; $i++) { 
		if ($number%$i == 0) {
			$result = false;
		}
	}
	if ($result == true) {
		echo "<h2>Yes, $number is a prime number.</h2>";
	} else {
		echo "<h2>No, $number is not a prime number.</h2>";
	}
}

?>

<form action="practical_12.php" method="post">
	<input type="text" name="number" placeholder="Enter the number">
	<input type="submit" name="submit">
</form>