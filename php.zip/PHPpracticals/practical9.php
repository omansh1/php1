<?php

$Servername = "localhost";
$username = "root";
$password = "";
$dbname = "student";

$conn = mysqli_connect($Servername, $username ,$password, $dbname);

$sql = "SELECT * FROM marksheet";
$sqldata = mysqli_query($conn, $sql);

while ($row = mysqli_fetch_array($sqldata, MYSQLI_ASSOC)) {

	$name = $row['name'];
	$rollno = $row['rollno'];
	$sub1 = $row['sub1'];
	$sub2 = $row['sub2'];
	$sub3 = $row['sub3'];

	echo "$name  $rollno  $sub1  #sub2  $sub3<br>";
}

?>