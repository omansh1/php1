<?php

if (isset($_POST['submit'])) {
	switch ($_POST['lang']) {
		case 'English':
			echo "<h1>Hello</h1>";
			break;

		case 'Hindi':
			echo "<h1>हैलो</h1>";
			break;

		case 'Punjabi':
			echo "<h1>ਸਤ ਸ੍ਰੀ ਅਕਾਲ</h1>";
			break;
	}
}
?>

<form action="practical_6.php" method="post"><br>
	<select name="lang">
		<option>Hindi</option>
		<option>English</option>
		<option>Punjabi</option>
	</select><br><br>
	<input type="submit" name="submit">
 </form>