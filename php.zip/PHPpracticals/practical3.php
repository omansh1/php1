<?php

echo "<h1>A part</h1>";
$data="  Removing white spaces from a string  ";
$data1=$string = str_replace(' ', '', $data);
echo "Before removing:".$data."<br>";
echo "After Removing :".$data1."<br>";

echo "<h1>B part</h1>";
$a = 'Checking if string contains jatin';
echo "$a<br>";
if (preg_match('/\jatin\b/',$a))
    echo 'Yes, the string contains jatin';

echo "<h1>C Part </h1>";
$strings = array('aac123', 'qiutoas', 'QASsdks');
foreach ($strings as $testcase) {
    if (ctype_lower($testcase)) {
        echo "The string *$testcase* consists of all lowercase letters.<br>";
    } else {
        echo "The string *$testcase* does not consist of all lowercase letters.<br>";
    }
}

echo "<h1>D Part </h1>";
$var = 'the quick brown fox jumps over the lazy dog.<br>';
echo "$var";
echo preg_replace('/the/', 'that', $var, 1);

?>