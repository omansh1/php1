<?php

if (isset($_POST['submit'])) {
	$n = $_POST['number'];
	$sum = 0;
	for ($i=1; $i<=2*$n ; $i = $i+2) { 
		$sum = $sum + $i;
	}
	echo "$sum";
}

?>

<form action="practical_14.php" method="post">
	<input type="text" name="number" placeholder="Enter the number">
	<input type="submit" name="submit">
</form>