<?php
$colors = array("Red", "Green", "Blue", "Yellow");
 
sort($colors);
print_r($colors);
?>