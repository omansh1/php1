<?php

if (isset($_POST['submit'])) {
	$n = $_POST['number'];
	for ($i=2; $i<=2*$n ; $i = $i+2) { 
		echo "$i<br>";
	}
}

?>

<form action="practical_13.php" method="post">
	<input type="text" name="number" placeholder="Enter the number">
	<input type="submit" name="submit">
</form>