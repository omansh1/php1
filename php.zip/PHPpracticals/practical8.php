<?php

session_start();

if (isset($_POST['submit'])) {

	$Servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "domain";

	$conn = mysqli_connect($Servername, $username ,$password, $dbname);

	$input = mysqli_real_escape_string($conn,$_POST['domain']);
	$domain = strtolower(substr($name, strpos($name, '@')));

	if (!empty($domain)) {

		$sql = "SELECT * from users WHERE domain = '$domain'";
		$result = mysqli_query($conn, $sql);
		$result_check = mysqli_num_rows($result);
		if ($result_check>0) {
			echo "Domain found in the database";
			
		} else {
			echo "Domain is not in the database.";;
		}
		
	} else {
		echo "Failed";;
		exit();
	}


} else {
	echo "Failed";
}

?>

<form action="practical_7.php" method="post">
	<input type="text" name="domain"><br>
	<input type="submit" name="submit">
</form>