<?php
$colors = array("white", "green", "red");
echo "<h1>Output is</h1>";
echo "<ul>";
foreach ($colors as $color) {
	echo "<h3><li>$color</li></h3>";
}
echo "</ul>";
?>