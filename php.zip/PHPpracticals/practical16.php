<?php

	if (isset($_POST["number1"])) {
		$num = $_POST['number1'];
		
		function series($num){  
			if($num == 0){  
		    	return 0;  
		    } else if( $num == 1){  
				return 1;  
			}  else {  
			return (series($num-1) + series($num-2));  
			}   
		}  
		/* Call Function. */  
		for ($i = 0; $i < $num; $i++){  
		echo series($i);  
		echo "\n";  
		}		
	}
	

?>

<form action="practical_16.php" method="post">
	Enter the number: <input type="text" name="number1"><br>
	<input type="submit" name="">
</form>