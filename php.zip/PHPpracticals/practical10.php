<?php

	if (isset($_POST["number1"])  && isset($_POST["number2"]) && isset($_POST["number3"])) {
		$n1 = $_POST['number1'];
		$n2 = $_POST['number2'];
		$n3 = $_POST['number3'];

		$max = $n1;
		$max = max($n1,$n2);
		$max = max($max,$n3);
		echo "<h1>Max of the three numbers is : $max</h1>";

	}
	

?>

<form action="practical_10.php" method="post">
	Enter first number  : <input type="text" name="number1"><br>
	Enter second number : <input type="text" name="number2"><br>
	Enter third number  : <input type="text" name="number3"><br>
	<input type="submit" name="">
</form>