<?php

if (isset($_POST["user_input"])) {
	$str = $_POST["user_input"];

	$n = strlen($str);
	$result = true;
	$temp;
	for ($i=0; $i < $n/2; $i++) {
		if (($str[$i] == $str[$n-$i-1]) && ($result == true)) {
			$result = true;
		}
		else {
			$result = false;
		}
	}
	if ($result == true) {
	echo "<h1>Yes, the entered string is palindrome</h1>";
	}
	else {
	echo "<h1>No, the entered string is not palindrome</h1>";
	}
}

?>

<form action="practical_6.php" method="post">
	Enter string to check whether palindrome or not : <input type="text" name="user_input"><br>
	<input type="submit" name="submit">
</form>