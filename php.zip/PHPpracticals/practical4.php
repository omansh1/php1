<?php

$date = strtotime("September 20, 2018 9:00 PM");
$remaining = $date - time();

echo "MY Birthday date on September 20, 2018 9:00 PM and time remaining is<br>";

$days_remaining = floor($remaining / 86400);
$hours_remaining = floor(($remaining % 86400) / 3600);
$minutes_remaining = floor(($remaining%3600)/60);
$seconds_remaining = floor(($remaining%60));
echo "There are $days_remaining days and $hours_remaining hours $minutes_remaining minutes $seconds_remaining seconds left";

?>