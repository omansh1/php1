<?php

	if (isset($_POST["number1"])) {
		$n = $_POST['number1'];
		$p = 1;
		for ($i=1; $i <=$n ; $i++) { 
			for ($j=1; $j <=$i ; $j++) { 
				echo "*";
			}echo "<br>";
		}
	}
	

?>

<form action="practical_17.php" method="post">
	Enter the number: <input type="text" name="number1"><br>
	<input type="submit" name="">
</form>