<?php

if (isset($_POST['submit'])) {
	$str = $_POST['str'];
	$str2 = strrev("$str");
	echo "<h1>Reversed string is $str2</h1>";
}
?>

<form action="practical_1.php" method="post"><input type="text" name="str" placeholder="Enter a string"><br><br><input type="submit" name="submit"></form>