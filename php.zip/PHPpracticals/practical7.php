<?php

session_start();

if (isset($_POST['submit'])) {

	$Servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "csdept";

	$conn = mysqli_connect($Servername, $username ,$password, $dbname);

	$user_id = mysqli_real_escape_string($conn,$_POST['email']);
	$user_pwd = mysqli_real_escape_string($conn,$_POST['password']);

	if (!empty($user_id) || !empty($user_pwd)) {

		$sql = "SELECT * from users WHERE user_id = '$user_id' or user_email = '$user_id'";
		$result = mysqli_query($conn, $sql);
		$result_check = mysqli_num_rows($result);
		if ($result_check>0) {
			if ($row = mysqli_fetch_assoc($result)) {
				//De-hashing the password
				$hashedPwdCheck = password_verify($user_pwd, $row['user_pwd']);
				if ($hashedPwdCheck == false) {
					header("Location: ../login.html?login=error");
					exit();
				} elseif ($hashedPwdCheck == true) {
					//Logged in the user here
					echo "Welcome, you are logged in";
					exit();
				}
			}
			
		} else {
			echo "Failed";;
		}
		
	} else {
		echo "Failed";;
		exit();
	}


} else {
	echo "Failed";
}

?>

<form action="practical_7.php" method="post">
	<input type="email" name="email"><br>
	<input type="password" name="password"><br>
	<input type="submit" name="submit">
</form>