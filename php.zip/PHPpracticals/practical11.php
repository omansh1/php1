<?php

	if (isset($_POST["number1"])) {
		$n = $_POST['number1'];
		$p = 1;
		for ($i=1; $i <=$n ; $i++) { 
			$p = $p*$i;
		}
		echo "<h2>Factorial of $n is $p</h2>";
	}
	

?>

<form action="practical_11.php" method="post">
	Enter number to calculate factorial : <input type="text" name="number1"><br>
	<input type="submit" name="">
</form>